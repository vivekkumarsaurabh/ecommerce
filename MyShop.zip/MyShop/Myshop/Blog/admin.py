from django.contrib import admin

from .models import Blogpost

admin.site.register(Blogpost)